"""Test Sample 3: Insecure Production Configuration (Triggers CWE-489 / CWE-209).

Drop this file into `mock_enterprise/config.py` to verify that `StaticVulnerabilityAuditorAgent`
flags active debug flags and weak static token signing mode.
"""

APP_NAME = "AcmeCorp Internal Portal"
ENVIRONMENT = "production"

# ERROR: Debug mode and stack trace exposure left enabled in production
DEBUG_MODE = True
EXPOSE_STACK_TRACES = True

# ERROR: Static fallback secret instead of rotatable key
TOKEN_SIGNING_MODE = "weak_static_secret"
SESSION_TIMEOUT_MINUTES = 30
