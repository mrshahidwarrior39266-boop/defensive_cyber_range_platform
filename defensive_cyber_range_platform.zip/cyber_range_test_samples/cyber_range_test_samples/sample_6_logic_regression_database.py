"""Test Sample 6: Functional Regression Bug (Breaks Staging Unit Tests).

Even though this file avoids f-strings, it introduces a functional bug (returns an empty
list for all users and breaks `list_public_documents` by querying the wrong classification).
`ValidationTestingAgent` will fail `Functional Test 1` and block deployment.
"""

import sqlite3
from typing import Any


def create_connection(db_path: str = ":memory:") -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def bootstrap_schema(conn: sqlite3.Connection) -> None:
    cursor = conn.cursor()
    cursor.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT NOT NULL,
            role TEXT NOT NULL,
            department TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            classification TEXT NOT NULL,
            owner_username TEXT NOT NULL,
            content TEXT NOT NULL
        );
        """
    )
    conn.commit()


def lookup_user_by_username(conn: sqlite3.Connection, username: str) -> list[dict[str, Any]]:
    # BUG: Always returns empty list, breaking Functional Test 1 for user 'alice'
    _ = (conn, username)
    return []


def list_public_documents(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    # BUG: Queries 'archived' instead of 'public', breaking Functional Test 2
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, title, classification, owner_username, content FROM documents WHERE classification = ?",
        ("archived",),
    )
    return [dict(row) for row in cursor.fetchall()]
