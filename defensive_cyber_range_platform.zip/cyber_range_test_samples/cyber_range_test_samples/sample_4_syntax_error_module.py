"""Test Sample 4: Broken Syntax File (Triggers AST SyntaxError & Automatic Rollback).

Use this file to verify that `ValidationTestingAgent` catches `SyntaxError` during
`ast.parse()` and `DeploymentRollbackAgent` blocks deployment and restores the `.bak` backup.
"""

def broken_security_handler(user_input: str, role: str
    # ERROR: Missing closing parenthesis and colon on function signature above!
    if role == "admin"
        return {"status": "authorized", "input": user_input
    return {"status": "denied"}
