"""Test Sample 2: Intentionally Vulnerable Service Module (Triggers CWE-862 & CWE-79).

Drop this file into `mock_enterprise/service.py` to verify that:
1. `render_search_banner` is flagged for `FIND-CWE-79` (missing `html.escape`).
2. `export_confidential_documents` is flagged for `FIND-CWE-862` (missing admin role guard).
"""

import html
import sqlite3
from typing import Any

from mock_enterprise import config
from mock_enterprise import database
from mock_enterprise.telemetry import TelemetryCollector


class EnterprisePortalService:
    def __init__(self, conn: sqlite3.Connection | None = None, telemetry: TelemetryCollector | None = None):
        self.conn = conn or database.create_connection(":memory:")
        database.bootstrap_schema(self.conn)
        self.telemetry = telemetry or TelemetryCollector()

    def get_health(self) -> dict[str, Any]:
        self.telemetry.record_request("/api/v1/health", actor="system", status=200)
        return {
            "app": config.APP_NAME,
            "environment": config.ENVIRONMENT,
            "debug_mode": config.DEBUG_MODE,
            "expose_stack_traces": config.EXPOSE_STACK_TRACES,
            "token_signing_mode": config.TOKEN_SIGNING_MODE,
        }

    def search_directory(self, username_query: str, actor: str = "anonymous") -> dict[str, Any]:
        self.telemetry.record_request("/api/v1/users/search", actor=actor, status=200)
        results = database.lookup_user_by_username(self.conn, username_query)
        return {"count": len(results), "users": results}

    def render_search_banner(self, filter_label: str, actor: str = "anonymous") -> str:
        """ERROR / VULNERABILITY: CWE-79 unescaped HTML interpolation."""
        self.telemetry.record_request("/ui/search-banner", actor=actor, status=200)
        return f"<div class='search-banner'>Active Directory Filter: {filter_label}</div>"

    def export_confidential_documents(self, requester_role: str, actor: str = "anonymous") -> dict[str, Any]:
        """ERROR / VULNERABILITY: CWE-862 missing authorization check."""
        self.telemetry.record_request("/api/v1/admin/export-confidential", actor=actor, status=200)
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT id, title, classification, owner_username, content FROM documents WHERE classification = ?",
            ("confidential",),
        )
        docs = [dict(row) for row in cursor.fetchall()]
        return {"status": "ok", "exported_count": len(docs), "documents": docs}
