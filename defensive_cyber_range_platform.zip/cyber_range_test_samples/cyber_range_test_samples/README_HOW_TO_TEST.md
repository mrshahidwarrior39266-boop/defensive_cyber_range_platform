# Faulty & Vulnerable Test Samples for Defensive Cyber Range

This folder contains **6 intentionally faulty/vulnerable Python files** plus an automated verification script (`run_sample_checks.py`) so you can test every detector, validator, and safety guard in your `defensive_cyber_range` platform.

## Included Faulty Files

| File | Intentional Error / Weakness | What It Tests |
| :--- | :--- | :--- |
| `sample_1_vulnerable_database.py` | **CWE-89** f-string SQL query in `lookup_user_by_username` | Verifies `StaticVulnerabilityAuditorAgent` flags `FIND-CWE-89` and `PatchGenerationAgent` rewrites it to parameterized `?` SQL. |
| `sample_2_vulnerable_service.py` | **CWE-862** missing role guard & **CWE-79** unescaped HTML return | Verifies detection and patching of missing `'admin'` role checks and unescaped HTML template rendering. |
| `sample_3_insecure_config.py` | **CWE-489 / CWE-209** `DEBUG_MODE = True`, `EXPOSE_STACK_TRACES = True`, `weak_static_secret` | Verifies configuration audit and production hardening patch generation. |
| `sample_4_syntax_error_module.py` | **Python `SyntaxError`** (unclosed function signature and dict literal) | Verifies `ValidationTestingAgent` catches syntax errors in staging and `DeploymentRollbackAgent` aborts/rolls back deployment. |
| `sample_5_prompt_injection_comments.py` | **5 Prompt-Injection Payloads** embedded in comments & docstrings | Verifies `PromptSanitizer` detects and redacts instruction-override attacks (`[REDACTED_PROMPT_INJECTION_ATTEMPT]`). |
| `sample_6_logic_regression_database.py` | **Functional Logic Bug** (returns empty user list & wrong document filter) | Verifies `ValidationTestingAgent` catches functional unit test regressions even when syntax is valid. |

## How to Test on Your Laptop

1. Extract `cyber_range_test_samples.zip` alongside `defensive_cyber_range/`:
   ```bash
   unzip cyber_range_test_samples.zip
   python3 cyber_range_test_samples/run_sample_checks.py ./defensive_cyber_range
   ```
2. Or overwrite the files in `defensive_cyber_range/mock_enterprise/` with Samples 1–3 and run a full simulation loop:
   ```bash
   cp cyber_range_test_samples/sample_1_vulnerable_database.py defensive_cyber_range/mock_enterprise/database.py
   cp cyber_range_test_samples/sample_2_vulnerable_service.py defensive_cyber_range/mock_enterprise/service.py
   cp cyber_range_test_samples/sample_3_insecure_config.py defensive_cyber_range/mock_enterprise/config.py
   cd defensive_cyber_range && python3 run_simulation.py --rounds 2
   ```
