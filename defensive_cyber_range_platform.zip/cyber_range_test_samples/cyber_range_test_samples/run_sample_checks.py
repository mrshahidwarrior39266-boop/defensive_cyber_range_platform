#!/usr/bin/env python3
"""Standalone runner that feeds the 6 faulty sample files into the Cyber Range agents
to prove detection, syntax rejection, functional test rejection, and prompt sanitization.
"""

import ast
from pathlib import Path
import shutil
import sys
import tempfile

HERE = Path(__file__).resolve().parent


def run_checks(cyber_range_root: Path) -> int:
    sys.path.insert(0, str(cyber_range_root))
    from agents.analysis_swarm import SurfaceMapperAgent, StaticVulnerabilityAuditorAgent
    from agents.defense_swarm import ValidationTestingAgent
    from agents.models import CandidatePatch
    from safety.controls import PromptSanitizer, SafetyController

    print("=" * 74)
    print(" RUNNING FAULTY FILE DIAGNOSTICS AGAINST DEFENSIVE CYBER RANGE AGENTS")
    print("=" * 74)

    with tempfile.TemporaryDirectory() as tmp:
        ws = Path(tmp) / "workspace"
        (ws / "mock_enterprise").mkdir(parents=True)
        # Copy Samples 1, 2, 3 into mock_enterprise/
        shutil.copyfile(HERE / "sample_1_vulnerable_database.py", ws / "mock_enterprise" / "database.py")
        shutil.copyfile(HERE / "sample_2_vulnerable_service.py", ws / "mock_enterprise" / "service.py")
        shutil.copyfile(HERE / "sample_3_insecure_config.py", ws / "mock_enterprise" / "config.py")
        (ws / "mock_enterprise" / "telemetry.py").write_text(
            (cyber_range_root / "mock_enterprise" / "telemetry.py").read_text(encoding="utf-8"),
            encoding="utf-8",
        )

        safety = SafetyController(sandbox_root=ws, audit_log_path=Path(tmp) / "audit.jsonl")
        mapper = SurfaceMapperAgent()
        auditor = StaticVulnerabilityAuditorAgent()

        # Check 1: Samples 1, 2, 3 must trigger all 4 CWE findings
        surfaces = mapper.map_workspace(ws, safety)
        findings = auditor.audit_workspace(ws, surfaces, safety)
        print(f"\n[Test 1] Samples 1-3 Static Audit Findings Detected: {len(findings)} / 4")
        for f in findings:
            print(f"  -> DETECTED {f.finding_id} ({f.cwe_id} | {f.severity}) in {f.file_path}:{f.line_number}")
        assert len(findings) == 4, f"Expected 4 findings, got {len(findings)}"

        # Check 2: Sample 4 (Syntax Error) must be rejected by ValidationTestingAgent
        validator = ValidationTestingAgent()
        broken_syntax_code = (HERE / "sample_4_syntax_error_module.py").read_text(encoding="utf-8")
        bad_syntax_patch = CandidatePatch(
            patch_id="TEST-BAD-SYNTAX",
            incident_id="INC-TEST-1",
            cwe_id="CWE-89",
            file_path="mock_enterprise/database.py",
            original_snippet="",
            patched_snippet=broken_syntax_code,
            unified_diff="",
            rationale="Test broken syntax rejection",
            generated_at_ms=0.0,
        )
        rep_syntax = validator.validate(bad_syntax_patch, ws, safety)
        print(
            f"\n[Test 2] Sample 4 (SyntaxError) Validation Result: "
            f"passed={rep_syntax.passed} | details={rep_syntax.details}"
        )
        assert not rep_syntax.passed and not rep_syntax.syntax_valid

        # Check 3: Sample 6 (Logic Regression) must fail functional tests in ValidationTestingAgent
        regression_code = (HERE / "sample_6_logic_regression_database.py").read_text(encoding="utf-8")
        bad_logic_patch = CandidatePatch(
            patch_id="TEST-BAD-LOGIC",
            incident_id="INC-TEST-2",
            cwe_id="CWE-89",
            file_path="mock_enterprise/database.py",
            original_snippet="",
            patched_snippet=regression_code,
            unified_diff="",
            rationale="Test functional regression rejection",
            generated_at_ms=0.0,
        )
        rep_logic = validator.validate(bad_logic_patch, ws, safety)
        print(
            f"\n[Test 3] Sample 6 (Functional Regression) Validation Result: "
            f"passed={rep_logic.passed} | syntax_valid={rep_logic.syntax_valid} | "
            f"functional_tests_passed={rep_logic.functional_tests_passed}"
        )
        assert not rep_logic.passed and rep_logic.syntax_valid and not rep_logic.functional_tests_passed

        # Check 4: Sample 5 (Prompt Injection Comments) must be scrubbed by PromptSanitizer
        sanitizer = PromptSanitizer()
        inj_text = (HERE / "sample_5_prompt_injection_comments.py").read_text(encoding="utf-8")
        cleaned, warnings = sanitizer.sanitize(inj_text)
        print(f"\n[Test 4] Sample 5 (Prompt Injection) Warnings Triggered: {len(warnings)}")
        for w in warnings:
            print(f"  -> SCRUBBED: {w}")
        assert len(warnings) >= 4 and "[REDACTED_PROMPT_INJECTION_ATTEMPT]" in cleaned

    print("\n" + "=" * 74)
    print(" ALL 6 FAULTY SAMPLE FILES DETECTED / BLOCKED AS EXPECTED!")
    print("=" * 74)
    return 0


if __name__ == "__main__":
    default_root = HERE.parent / "defensive_cyber_range"
    root_arg = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else default_root
    sys.exit(run_checks(root_arg))
