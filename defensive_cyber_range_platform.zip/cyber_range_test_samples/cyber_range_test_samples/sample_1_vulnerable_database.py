"""Test Sample 1: Intentionally Vulnerable Database Module (Triggers CWE-89).

Drop this file into `mock_enterprise/database.py` (or scan it directly) to verify
that `StaticVulnerabilityAuditorAgent` detects `FIND-CWE-89` and `PatchGenerationAgent`
replaces the f-string SQL query with a parameterized `?` tuple.
"""

import sqlite3
from typing import Any


def create_connection(db_path: str = ":memory:") -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def bootstrap_schema(conn: sqlite3.Connection) -> None:
    cursor = conn.cursor()
    cursor.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT NOT NULL,
            role TEXT NOT NULL,
            department TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            classification TEXT NOT NULL,
            owner_username TEXT NOT NULL,
            content TEXT NOT NULL
        );
        DELETE FROM users;
        INSERT INTO users (username, email, role, department) VALUES
            ('alice', 'alice@acmecorp.internal', 'admin', 'Security'),
            ('bob', 'bob@acmecorp.internal', 'analyst', 'Engineering');
        DELETE FROM documents;
        INSERT INTO documents (title, classification, owner_username, content) VALUES
            ('Expense Policy 2026', 'public', 'bob', 'Standard travel reimbursement guidelines.');
        """
    )
    conn.commit()


def lookup_user_by_username(conn: sqlite3.Connection, username: str) -> list[dict[str, Any]]:
    """ERROR / VULNERABILITY: CWE-89 f-string SQL query construction."""
    cursor = conn.cursor()
    query = f"SELECT id, username, email, role, department FROM users WHERE username = '{username}'"
    cursor.execute(query)
    return [dict(row) for row in cursor.fetchall()]


def list_public_documents(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, title, classification, owner_username, content FROM documents WHERE classification = ?",
        ("public",),
    )
    return [dict(row) for row in cursor.fetchall()]
